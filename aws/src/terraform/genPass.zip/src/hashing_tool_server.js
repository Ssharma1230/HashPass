"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.extractHash = void 0;
exports.hashText = hashText;
const argon2_1 = __importDefault(require("argon2"));
// Async function to hash text
async function hashText(text, argon2_salt) {
    try {
        const dataToHash = typeof text === 'string' ? text : JSON.stringify(text, null, 2);
        const slt = Buffer.from(argon2_salt, 'utf8');
        const hashValue = await argon2_1.default.hash(dataToHash, {
            salt: slt,
            type: argon2_1.default.argon2id,
            timeCost: 2, // Number of iterations.
            memoryCost: 65536, // Memory in KiB.
            hashLength: 32, // Length of the resulting hash.
            parallelism: 1,
        });
        console.log("Hash Value: ", hashValue);
        return {
            statusCode: 200,
            body: JSON.stringify({ hash: hashValue }),
        };
    }
    catch (error) {
        console.error('Hashing error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: error instanceof Error ? error.message : String(error) }),
        };
    }
}
// Extract hash
const extractHash = (input) => {
    console.log("extractHash input: ", input);
    const parts = input.split('$');
    return parts.length > 3 ? parts.slice(4).join('$') : '';
};
exports.extractHash = extractHash;
